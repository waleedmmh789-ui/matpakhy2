import 'dart:convert';
import 'package:flutter/services.dart';

/// حاسبة القيم الغذائية بالجرام فقط. القيم في القاعدة لكل 100 جرام.
class NutritionCalculator {
  Map<String, dynamic> _database = {};
  List<String> _keysLongestFirst = [];

  Future<void> loadDatabase() async {
    final String jsonString = await rootBundle.loadString('assets/data/nutrition_db.json');
    _setDatabase(json.decode(jsonString) as Map<String, dynamic>);
  }

  void _setDatabase(Map<String, dynamic> db) {
    _database = db;
    // الأطول أولاً حتى يفوز "أرز مطبوخ" على "أرز".
    _keysLongestFirst = db.keys.toList()..sort((a, b) => b.length.compareTo(a.length));
  }

  static const _arabicDigits = '٠١٢٣٤٥٦٧٨٩';

  String _normalize(String s) {
    final b = StringBuffer();
    for (final ch in s.split('')) {
      final i = _arabicDigits.indexOf(ch);
      b.write(i >= 0 ? '$i' : ch);
    }
    return b.toString().replaceAll('٫', '.').replaceAll(RegExp(r'[\u064B-\u0652]'), '').trim();
  }

  static const Map<String, String> _enNames = {
    'أرز': 'Rice',
    'أرز مطبوخ': 'Cooked rice',
    'مكرونة': 'Pasta',
    'مكرونة مسلوقة': 'Boiled pasta',
    'عدس': 'Lentils',
    'عدس مطبوخ': 'Cooked lentils',
    'فول': 'Fava beans',
    'فول مدمس': 'Foul medames',
    'حمص': 'Chickpeas',
    'شوفان': 'Oats',
    'دقيق': 'Flour',
    'دقيق ذرة': 'Cornflour',
    'فريك': 'Freekeh',
    'خبز بلدي': 'Baladi bread',
    'خبز أبيض': 'White bread',
    'بقسماط': 'Breadcrumbs',
    'فراخ': 'Chicken',
    'فراخ مشوية': 'Grilled chicken',
    'صدور دجاج': 'Chicken breast',
    'لحمة': 'Beef',
    'لحمة مفرومة': 'Minced meat',
    'لحمة مطبوخة': 'Cooked meat',
    'ضاني': 'Lamb',
    'كبدة': 'Liver',
    'سمك': 'Fish',
    'تونة': 'Tuna',
    'جمبري': 'Shrimp',
    'بيض': 'Eggs',
    'بياض بيض': 'Egg whites',
    'لبن': 'Milk',
    'لبن خالي الدسم': 'Skim milk',
    'زبادي': 'Yogurt',
    'زبادي خالي الدسم': 'Fat-free yogurt',
    'جبنة فيتا': 'Feta cheese',
    'جبنة': 'Cheese',
    'جبنة شيدر': 'Cheddar cheese',
    'قشطة': 'Cream (qishta)',
    'زبدة': 'Butter',
    'سمن': 'Ghee',
    'زيت': 'Oil',
    'زيت زيتون': 'Olive oil',
    'بطاطس': 'Potatoes',
    'بطاطا': 'Sweet potato',
    'جزر': 'Carrots',
    'طماطم': 'Tomatoes',
    'خيار': 'Cucumber',
    'بصل': 'Onion',
    'ثوم': 'Garlic',
    'كوسة': 'Zucchini',
    'باذنجان': 'Eggplant',
    'فلفل': 'Pepper',
    'قرنبيط': 'Cauliflower',
    'ملوخية': 'Molokhia',
    'بامية': 'Okra',
    'جرجير': 'Arugula',
    'خس': 'Lettuce',
    'بسلة': 'Peas',
    'سبانخ': 'Spinach',
    'أفوكادو': 'Avocado',
    'موز': 'Banana',
    'تفاح': 'Apple',
    'فراولة': 'Strawberry',
    'كمثرى': 'Pear',
    'كيوي': 'Kiwi',
    'برتقال': 'Orange',
    'تمر': 'Dates',
    'سكر': 'Sugar',
    'عسل': 'Honey',
    'عسل أسود': 'Black honey (molasses)',
    'طحينة': 'Tahini',
    'لوز': 'Almonds',
    'جوز': 'Walnuts',
    'فول سوداني': 'Peanuts',
    'بذر كتان': 'Flaxseed',
    'حلبة': 'Fenugreek',
  };

  static const List<(String, String)> _enAliases = [
    ('grilled chicken', 'فراخ مشوية'),
    ('fat-free yogurt', 'زبادي خالي الدسم'),
    ('fat free yogurt', 'زبادي خالي الدسم'),
    ('chicken breast', 'صدور دجاج'),
    ('cooked lentil', 'عدس مطبوخ'),
    ('boiled pasta', 'مكرونة مسلوقة'),
    ('foul medames', 'فول مدمس'),
    ('baladi bread', 'خبز بلدي'),
    ('sweet potato', 'بطاطا'),
    ('cooked rice', 'أرز مطبوخ'),
    ('white bread', 'خبز أبيض'),
    ('bread crumb', 'بقسماط'),
    ('minced meat', 'لحمة مفرومة'),
    ('cooked meat', 'لحمة مطبوخة'),
    ('cauliflower', 'قرنبيط'),
    ('strawberrie', 'فراولة'),
    ('black honey', 'عسل أسود'),
    ('corn flour', 'دقيق ذرة'),
    ('breadcrumb', 'بقسماط'),
    ('strawberry', 'فراولة'),
    ('fava bean', 'فول'),
    ('cornflour', 'دقيق ذرة'),
    ('egg white', 'بياض بيض'),
    ('skim milk', 'لبن خالي الدسم'),
    ('olive oil', 'زيت زيتون'),
    ('courgette', 'كوسة'),
    ('aubergine', 'باذنجان'),
    ('fenugreek', 'حلبة'),
    ('macaroni', 'مكرونة'),
    ('chickpea', 'حمص'),
    ('cucumber', 'خيار'),
    ('zucchini', 'كوسة'),
    ('eggplant', 'باذنجان'),
    ('molokhia', 'ملوخية'),
    ('molasses', 'عسل أسود'),
    ('flaxseed', 'بذر كتان'),
    ('freekeh', 'فريك'),
    ('chicken', 'فراخ'),
    ('yoghurt', 'زبادي'),
    ('cheddar', 'جبنة شيدر'),
    ('arugula', 'جرجير'),
    ('lettuce', 'خس'),
    ('spinach', 'سبانخ'),
    ('avocado', 'أفوكادو'),
    ('lentil', 'عدس'),
    ('shrimp', 'جمبري'),
    ('yogurt', 'زبادي'),
    ('cheese', 'جبنة'),
    ('qishta', 'قشطة'),
    ('butter', 'زبدة'),
    ('potato', 'بطاطس'),
    ('carrot', 'جزر'),
    ('tomato', 'طماطم'),
    ('garlic', 'ثوم'),
    ('pepper', 'فلفل'),
    ('rocket', 'جرجير'),
    ('banana', 'موز'),
    ('orange', 'برتقال'),
    ('tahini', 'طحينة'),
    ('almond', 'لوز'),
    ('walnut', 'جوز'),
    ('peanut', 'فول سوداني'),
    ('pasta', 'مكرونة'),
    ('flour', 'دقيق'),
    ('bread', 'خبز بلدي'),
    ('liver', 'كبدة'),
    ('cream', 'قشطة'),
    ('onion', 'بصل'),
    ('apple', 'تفاح'),
    ('sugar', 'سكر'),
    ('honey', 'عسل'),
    ('rice', 'أرز'),
    ('foul', 'فول'),
    ('beef', 'لحمة'),
    ('meat', 'لحمة'),
    ('lamb', 'ضاني'),
    ('fish', 'سمك'),
    ('tuna', 'تونة'),
    ('milk', 'لبن'),
    ('feta', 'جبنة فيتا'),
    ('ghee', 'سمن'),
    ('okra', 'بامية'),
    ('pear', 'كمثرى'),
    ('kiwi', 'كيوي'),
    ('date', 'تمر'),
    ('oat', 'شوفان'),
    ('egg', 'بيض'),
    ('oil', 'زيت'),
    ('pea', 'بسلة'),
  ];

  /// يطابق اسم مكوّن إنجليزي (مثل: 250 g chicken) مع مفتاح القاعدة العربي.
  String? _matchEnglish(String lower) {
    for (final (term, key) in _enAliases) {
      if (RegExp('\\b${RegExp.escape(term)}(s|es)?\\b').hasMatch(lower)) return key;
    }
    return null;
  }

  Map<String, dynamic> calculateNutrition(String rawInput, {bool en = false}) {
    final input = _normalize(rawInput);
    final lower = input.toLowerCase();

    if (RegExp(r'كيلو|كوب|ملعقة|ملعقه|رطل').hasMatch(input) ||
        RegExp(r'\b(kg|kilo|kilos|cup|cups|tbsp|tsp|spoon|spoons|oz|lb|lbs|pound|pounds)\b').hasMatch(lower)) {
      throw Exception(en
          ? 'The calculator uses grams only. Write the weight in grams, e.g. "250 g beef".'
          : 'الحاسبة بالجرام فقط. اكتب الوزن بالجرام، مثلاً: "250 جرام لحمة".');
    }

    final quantityInGrams = _parseQuantity(input);
    if (quantityInGrams <= 0) {
      throw Exception(en
          ? 'Sorry, I could not understand the weight. Try "250 g" or "500 g".'
          : 'عذراً، لم أفهم الوزن. جرب تكتب "250 جرام" أو "500 جرام".');
    }

    String ingredientName = _parseIngredient(input);
    if (!_database.containsKey(ingredientName) && RegExp(r'[a-z]').hasMatch(lower)) {
      ingredientName = _matchEnglish(lower) ?? ingredientName;
    }
    if (!_database.containsKey(ingredientName)) {
      final shown = ingredientName.isEmpty ? (en ? 'ingredient' : 'المكون') : ingredientName;
      throw Exception(en
          ? 'Sorry, the ingredient "$shown" is not in our database.'
          : 'عذراً، المكون "$shown" غير موجود في قاعدة بياناتنا.');
    }

    final data = _database[ingredientName] as Map<String, dynamic>;
    final factor = quantityInGrams / 100.0;

    return {
      'ingredient_name': ingredientName,
      'ingredient_name_en': _enNames[ingredientName] ?? ingredientName,
      'weight_grams': quantityInGrams,
      'calories': (data['calories'] as num) * factor,
      'protein': (data['protein'] as num) * factor,
      'carbs': (data['carbs'] as num) * factor,
      'fat': (data['fat'] as num) * factor,
    };
  }

  double _parseQuantity(String input) {
    final match = RegExp(r'(\d+(\.\d+)?)').firstMatch(input);
    if (match != null && match.group(1) != null) {
      return double.parse(match.group(1)!);
    }
    return 0;
  }

  String _parseIngredient(String input) {
    for (final key in _keysLongestFirst) {
      if (input.contains(key)) return key;
    }
    return input
        .replaceAll(RegExp(r'\d+(\.\d+)?'), '')
        .replaceAll('جرام', '')
        .replaceAll('غرام', '')
        .replaceAll('جم', '')
        .trim();
  }
}
