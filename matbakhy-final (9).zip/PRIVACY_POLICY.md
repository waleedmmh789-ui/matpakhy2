# سياسة الخصوصية — مطبخي / Privacy Policy — Matbakhy

**آخر تحديث / Last updated:** 26 نوفمبر 2026 / November 26, 2026

## العربية

تطبيق «مطبخي - وصفات وحاسبة سعرات» لا يتطلب حساباً ولا تسجيل دخول، ولا نرسل أي معلومات عنك إلى خوادمنا.

**البيانات المخزنة على جهازك فقط:** الوصفات المفضلة، قائمة المشتريات، جدول الوجبات، إعدادات المظهر، حالة الاشتراك، والصور التي تختارها لوصفاتك. تُحذف بحذف التطبيق أو مسح بياناته.

**الصلاحيات:** الإشعارات (تنبيه انتهاء مؤقت الطبخ)، الكاميرا/الصور (فقط عند إضافة صورة لوصفة، وتُحفظ على جهازك)، الإنترنت (للإعلانات والاشتراك). لا يستخدم التطبيق الميكروفون ولا الموقع ولا جهات الاتصال.

**مؤقت الطبخ والصوت:** يُشغَّل صوت تنبيه مضمّن داخل التطبيق عند انتهاء المؤقت، محلياً فقط، دون تسجيل أي صوت أو إرسال أي بيانات.

**الإعلانات:** يعرض التطبيق إعلانات عبر Google AdMob. قد تجمع Google وشركاؤها معرّف الإعلانات وبيانات الجهاز والاستخدام (مثل عنوان IP) لعرض الإعلانات وقياس أدائها ومنع الاحتيال، وقد يُطلب منك الموافقة على الإعلانات المخصصة في المناطق التي يشترط فيها القانون ذلك. يمكنك إعادة ضبط معرّف الإعلانات أو إلغاء التخصيص من إعدادات جهازك. المشتركون في النسخة المميزة لا يرون إعلانات. المزيد: https://policies.google.com/technologies/partner-sites

**صور الوصفات الموضحة:** للوصفات بلا صورة مضمّنة يطلب التطبيق صورة توضيحية عامة من خدمة TheMealDB بكلمة وصفية عامة (مثل rice)، ويحفظها على جهازك. لا تُرسل أي معلومات شخصية، وقد ترى الخدمة عنوان IP كأي موقع. تظهر صور بديلة مضمّنة إن تعذّر التحميل.

**الاشتراك المميز:** (أسبوعي/شهري/سنوي، يتجدد تلقائياً) تتم المدفوعات بالكامل عبر Google Play، ولا نرى ولا نخزن بيانات بطاقتك. يمكنك الإلغاء من Google Play ← المدفوعات والاشتراكات.

**تنبيه حاسبة السعرات:** القيم الغذائية والسعرات تقديرية وللمعلومات العامة فقط، ولا تُعدّ نصيحة طبية أو غذائية، ولا تغني عن استشارة الطبيب أو أخصائي التغذية.

**مشاركة الوصفات:** تُنشأ صورة الوصفة على جهازك فقط، ثم تختار أنت تطبيق المشاركة عبر قائمة المشاركة في أندرويد. لا نرسلها إلى أي خادم من جهتنا.

**تقييم التطبيق:** قد يظهر طلب تقييم اختياري (مرة كل 3 أيام تقريباً حتى تقيّم) عبر نافذة Google Play الرسمية، دون أي مقابل.

**الأطفال:** التطبيق لا يستهدف الأطفال دون 13 عاماً ولا يجمع بيانات منهم عن قصد.

**التواصل:** waleedmmh789@gmail.com

## English

Matbakhy requires no account or sign-in, and we do not send information about you to our own servers.

**Stored on your device only:** favorite recipes, shopping list, meal plan, theme settings, subscription status, and photos you choose for your recipes. Deleted when you uninstall the app or clear its data.

**Permissions:** Notifications (cooking-timer alerts), Camera/Photos (only when you add a photo to a recipe; stored on your device), Internet (for ads and subscriptions). The app does not use the microphone, location, or contacts.

**Cooking timer sound:** A built-in alarm sound plays locally when the timer ends. No audio is recorded and no data is sent.

**Ads:** The app shows ads via Google AdMob. Google and its partners may collect the advertising ID and device/usage data (such as IP address) to serve and measure ads and prevent fraud, and you may be asked for consent to personalized ads where required by law. You can reset your advertising ID or opt out of personalization in your device settings. Premium subscribers see no ads. More: https://policies.google.com/technologies/partner-sites

**Recipe pictures:** For recipes without a built-in picture, the app requests a generic illustrative picture from TheMealDB using a general keyword (e.g. "rice") and saves it on your device. No personal information is sent, though the service may see your IP address like any website. Built-in placeholder pictures are shown if downloading fails.

**Premium subscription (weekly / monthly / yearly, auto-renewing):** Payments are handled entirely by Google Play; we never see or store your card details. Cancel anytime in Google Play → Payments & subscriptions.

**Calorie calculator disclaimer:** Nutrition and calorie values are estimates for general information only. They are not medical or dietary advice and do not replace consulting a doctor or dietitian.

**Recipe sharing:** The recipe image is created on your device only; you then choose the sharing app via Android's share sheet. We do not upload it to any server.

**App rating:** An optional rating request may appear (about every 3 days until you rate) through the official Google Play review dialog, with no reward offered.

**Children:** The app is not directed to children under 13 and does not knowingly collect their data.

**Contact:** waleedmmh789@gmail.com
