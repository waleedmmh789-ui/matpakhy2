import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models/recipe.dart';
import 'recipe_image_service.dart';

/// مشاركة الوصفة كصورة واحدة مدمجة (1080×1080 PNG) عبر Android Sharesheet.
/// share_plus يستخدم Intent.ACTION_SEND مع FileProvider لمشاركة الملف بأمان،
/// فتظهر كل تطبيقات المشاركة (فيسبوك، واتساب، تيليجرام...).
class RecipeShareService {
  RecipeShareService._();

  static const String packageName = 'com.nader.matbakhi';
  static const String playUrl = 'https://play.google.com/store/apps/details?id=$packageName';
  static const String appNameAr = 'مطبخي - وصفات وحاسبة سعرات';
  static const String appNameEn = 'Matbakhy - Recipes & Calorie Calculator';

  static const double _size = 1080;
  static const double _imageH = 400;
  static const double _footerTop = 930;
  static const double _margin = 40;
  static const double _gap = 24;
  static const Color _orange = Color(0xFFFF6B35);
  static const Color _deep = Color(0xFFD84315);

  /// يرسم البطاقة ويفتح قائمة المشاركة.
  static Future<void> shareRecipe(
    Recipe r, {
    required bool en,
    String? userImagePath,
  }) async {
    final bytes = await renderCard(r, en: en, userImagePath: userImagePath);
    final tmp = await getTemporaryDirectory();
    final dir = Directory(p.join(tmp.path, 'share'));
    if (!await dir.exists()) await dir.create(recursive: true);
    final file = File(p.join(dir.path, 'matbakhy_${r.id}.png'));
    await file.writeAsBytes(bytes, flush: true);

    final text = en
        ? '${r.title(en)}\nFull recipe in the Matbakhy app:\n$playUrl'
        : '${r.title(en)}\nالوصفة كاملة في تطبيق «$appNameAr»:\n$playUrl';

    await Share.shareXFiles(
      [XFile(file.path, mimeType: 'image/png', name: 'matbakhy_${r.id}.png')],
      text: text,
      subject: r.title(en),
    );
  }

  // ---------------------------------------------------------------- الرسم

  static Future<ui.Image?> _decode(Future<Uint8List> Function() load, int width) async {
    try {
      final bytes = await load();
      final codec = await ui.instantiateImageCodec(bytes, targetWidth: width);
      final frame = await codec.getNextFrame();
      return frame.image;
    } catch (_) {
      return null;
    }
  }

  static TextPainter _tp(
    String text, {
    required double size,
    required Color color,
    required double width,
    required bool rtl,
    FontWeight weight = FontWeight.normal,
    int? maxLines,
    double height = 1.35,
    bool? forceRtl,
  }) {
    final isRtl = forceRtl ?? rtl;
    // المحاذاة تتبع اتجاه الواجهة حتى لو كان النص نفسه LTR (مثل الرابط)
    return TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(fontSize: size, color: color, fontWeight: weight, height: height),
      ),
      textDirection: isRtl ? TextDirection.rtl : TextDirection.ltr,
      textAlign: rtl ? TextAlign.right : TextAlign.left,
      maxLines: maxLines,
      ellipsis: maxLines != null ? '…' : null,
    )..layout(minWidth: width, maxWidth: width);
  }

  static void _drawCover(Canvas c, ui.Image img, Rect dst) {
    final iw = img.width.toDouble(), ih = img.height.toDouble();
    final scale = math.max(dst.width / iw, dst.height / ih);
    final sw = dst.width / scale, sh = dst.height / scale;
    final src = Rect.fromLTWH((iw - sw) / 2, (ih - sh) / 2, sw, sh);
    c.drawImageRect(img, src, dst, Paint()..filterQuality = FilterQuality.high);
  }

  static void _drawLogo(Canvas c, ui.Image? logo, Rect dst) {
    final rr = RRect.fromRectAndRadius(dst, Radius.circular(dst.width * 0.22));
    if (logo == null) {
      c.drawRRect(rr, Paint()..color = Colors.white);
      return;
    }
    c.save();
    c.clipRRect(rr);
    _drawCover(c, logo, dst);
    c.restore();
  }

  static void _drawSection(
    Canvas c, {
    required String title,
    required List<String> items,
    required double x,
    required double top,
    required double bottom,
    required double colW,
    required bool rtl,
    required bool numbered,
    required String moreText,
  }) {
    var y = top;
    final head = _tp(title, size: 34, color: _deep, width: colW, rtl: rtl, weight: FontWeight.bold);
    head.paint(c, Offset(x, y));
    y += head.height + 4;
    c.drawRect(Rect.fromLTWH(x, y, colW, 3), Paint()..color = _orange);
    y += 14;

    var shown = 0;
    for (var i = 0; i < items.length; i++) {
      final label = numbered ? '${i + 1}. ${items[i]}' : '• ${items[i]}';
      final tp = _tp(label,
          size: 26,
          color: const Color(0xFF333333),
          width: colW,
          rtl: rtl,
          maxLines: numbered ? 3 : 2,
          height: 1.3);
      if (y + tp.height > bottom - 40) break;
      tp.paint(c, Offset(x, y));
      y += tp.height + 8;
      shown++;
    }
    if (shown < items.length) {
      final more = _tp(moreText, size: 24, color: _orange, width: colW, rtl: rtl, weight: FontWeight.bold);
      more.paint(c, Offset(x, math.min(y, bottom - more.height - 4)));
    }
  }

  static Future<Uint8List> renderCard(
    Recipe r, {
    required bool en,
    String? userImagePath,
  }) async {
    final rtl = !en;

    // الصورة: صورة المستخدم لو موجودة، وإلا الصورة الافتراضية للوصفة.
    ui.Image? photo;
    if (userImagePath != null) {
      photo = await _decode(() => File(userImagePath).readAsBytes(), 1080);
    }
    if (photo == null && r.image.isNotEmpty) {
      photo = await _decode(() async => (await rootBundle.load(r.image)).buffer.asUint8List(), 1080);
    }
    if (photo == null) {
      final cached = await RecipeImageService.cachedFile(r); // النسخة المحفوظة محلياً (بدون شبكة)
      if (cached != null) photo = await _decode(() => cached.readAsBytes(), 1080);
    }
    photo ??= await _decode(
        () async => (await rootBundle.load(RecipeImageService.fallbackAsset(r))).buffer.asUint8List(), 1080);
    final logo = await _decode(
        () async => (await rootBundle.load('assets/icon/icon.png')).buffer.asUint8List(), 256);

    final recorder = ui.PictureRecorder();
    final c = Canvas(recorder, const Rect.fromLTWH(0, 0, _size, _size));

    // الخلفية
    c.drawRect(const Rect.fromLTWH(0, 0, _size, _size), Paint()..color = const Color(0xFFFFF8F0));

    // صورة الوصفة
    const imgRect = Rect.fromLTWH(0, 0, _size, _imageH);
    if (photo != null) {
      _drawCover(c, photo, imgRect);
    } else {
      c.drawRect(
        imgRect,
        Paint()
          ..shader = ui.Gradient.linear(
              const Offset(0, 0), const Offset(_size, _imageH), [_orange, _deep]),
      );
    }
    // تدرج أسود أسفل الصورة لقراءة العنوان + تدرج خفيف أعلاها
    c.drawRect(
      imgRect,
      Paint()
        ..shader = ui.Gradient.linear(
          const Offset(0, 0),
          const Offset(0, _imageH),
          const [Color(0x66000000), Color(0x00000000), Color(0x00000000), Color(0xCC000000)],
          const [0.0, 0.25, 0.45, 1.0],
        ),
    );

    // الشعار + اسم التطبيق أعلى الصورة
    const topLogo = 64.0;
    final logoX = rtl ? _size - _margin - topLogo : _margin;
    _drawLogo(c, logo, Rect.fromLTWH(logoX, 28, topLogo, topLogo));
    final nameW = _size - _margin * 2 - topLogo - 16;
    final nameTp = _tp(en ? appNameEn : appNameAr,
        size: 28, color: Colors.white, width: nameW, rtl: rtl, weight: FontWeight.bold, maxLines: 1);
    nameTp.paint(c, Offset(rtl ? _margin : _margin + topLogo + 16, 28 + (topLogo - nameTp.height) / 2));

    // العنوان + السطر الفرعي أسفل الصورة
    const textW = _size - _margin * 2;
    final meta = [
      r.cuisine(en),
      if (r.time(en).isNotEmpty) r.time(en),
      en ? 'Serves ${r.servings}' : 'تكفي ${r.servings}',
    ].join('  •  ');
    final metaTp = _tp(meta, size: 28, color: const Color(0xE6FFFFFF), width: textW, rtl: rtl, maxLines: 1);
    final titleTp = _tp(r.title(en),
        size: 54, color: Colors.white, width: textW, rtl: rtl, weight: FontWeight.bold, maxLines: 2, height: 1.2);
    var ty = _imageH - 20 - metaTp.height;
    metaTp.paint(c, Offset(_margin, ty));
    ty -= titleTp.height + 4;
    titleTp.paint(c, Offset(_margin, ty));

    // العمودان: المقادير + الخطوات
    const colW = (_size - _margin * 2 - _gap) / 2;
    const rightX = _margin + colW + _gap;
    const leftX = _margin;
    final ingX = rtl ? rightX : leftX;
    final stepsX = rtl ? leftX : rightX;
    const top = _imageH + 28;

    _drawSection(c,
        title: en ? 'Ingredients' : 'المقادير',
        items: r.ingredientList(en),
        x: ingX,
        top: top,
        bottom: _footerTop,
        colW: colW,
        rtl: rtl,
        numbered: false,
        moreText: en ? '… more in the app' : '… والمزيد في التطبيق');
    _drawSection(c,
        title: en ? 'Method' : 'طريقة التحضير',
        items: r.steps(en).map((s) => s.text).toList(),
        x: stepsX,
        top: top,
        bottom: _footerTop,
        colW: colW,
        rtl: rtl,
        numbered: true,
        moreText: en ? '… full steps in the app' : '… الخطوات كاملة في التطبيق');

    // الفوتر: الشعار + اسم التطبيق + رابط Google Play
    const footerH = _size - _footerTop;
    c.drawRect(
      const Rect.fromLTWH(0, _footerTop, _size, footerH),
      Paint()
        ..shader = ui.Gradient.linear(
            const Offset(0, _footerTop), const Offset(_size, _size), [_orange, _deep]),
    );
    const footLogo = 96.0;
    final footLogoX = rtl ? _size - _margin - footLogo : _margin;
    _drawLogo(c, logo, Rect.fromLTWH(footLogoX, _footerTop + (footerH - footLogo) / 2, footLogo, footLogo));
    const footTextW = _size - _margin * 2 - footLogo - 20;
    final footTextX = rtl ? _margin : _margin + footLogo + 20;
    final f1 = _tp(en ? appNameEn : appNameAr,
        size: 34, color: Colors.white, width: footTextW, rtl: rtl, weight: FontWeight.bold, maxLines: 1);
    final f2 = _tp(en ? 'Get the app free on Google Play' : 'حمّل التطبيق مجاناً من Google Play',
        size: 26, color: const Color(0xFFFFE0B2), width: footTextW, rtl: rtl, maxLines: 1);
    final f3 = _tp('play.google.com/store/apps/details?id=$packageName',
        size: 23, color: Colors.white, width: footTextW, rtl: rtl, maxLines: 1, forceRtl: false);
    final blockH = f1.height + f2.height + f3.height + 8;
    var fy = _footerTop + (footerH - blockH) / 2;
    f1.paint(c, Offset(footTextX, fy));
    fy += f1.height + 4;
    f2.paint(c, Offset(footTextX, fy));
    fy += f2.height + 4;
    f3.paint(c, Offset(footTextX, fy));

    final picture = recorder.endRecording();
    final image = await picture.toImage(_size.toInt(), _size.toInt());
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    photo?.dispose();
    logo?.dispose();
    image.dispose();
    if (data == null) throw StateError('تعذر إنشاء الصورة');
    return data.buffer.asUint8List();
  }
}
