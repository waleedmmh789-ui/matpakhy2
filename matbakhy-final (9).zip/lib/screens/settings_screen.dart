import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../localization/app_localizations.dart';
import '../providers/premium_provider.dart';
import '../providers/recipes_provider.dart';
import '../providers/settings_provider.dart';
import '../widgets/matbakhy_logo.dart';
import '../widgets/banner_ad_widget.dart';
import '../widgets/responsive_body.dart';
import 'premium_screen.dart';
import 'privacy_policy_screen.dart';
import 'refund_policy_screen.dart';
import 'support_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final settings = context.watch<SettingsProvider>();
    final recipes = context.watch<RecipesProvider>().recipes;
    final cuisinesCount = recipes.map((r) => r.cuisineAr).toSet().length;
    final en = Localizations.localeOf(context).languageCode == 'en';

    return Scaffold(
      appBar: AppBar(title: Text(t.translate('settings'))),
      bottomNavigationBar: const SafeArea(top: false, child: BannerAdWidget()),
      body: ResponsiveBody(
        child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Center(child: MatbakhyLogo(size: 90)),
          const SizedBox(height: 16),
          Card(
            color: Colors.deepOrange.withOpacity(0.12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: const BorderSide(color: Colors.deepOrange),
            ),
            child: ListTile(
              leading: const Text('⭐', style: TextStyle(fontSize: 26)),
              title: Text(
                context.watch<PremiumProvider>().isPremium
                    ? (en ? 'You are a Premium subscriber' : 'أنت مشترك في النسخة المميزة')
                    : (en ? 'Remove ads ⭐' : 'إزالة الإعلانات ⭐'),
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: context.watch<PremiumProvider>().isPremium
                  ? null
                  : Text(en ? 'Weekly, monthly or yearly plan — browse without ads' : 'اشتراك أسبوعي أو شهري أو سنوي — تصفح بدون إعلانات'),
              trailing: Icon(Directionality.of(context) == TextDirection.rtl
                  ? Icons.chevron_left
                  : Icons.chevron_right),
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const PremiumScreen())),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.soup_kitchen, color: Colors.deepOrange),
              title: Text(t.translate('banner_title'),
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(en
                  ? '${recipes.length} recipes from $cuisinesCount Arab cuisines'
                  : '${recipes.length} وصفة من $cuisinesCount مطابخ عربية'),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: SwitchListTile(
              title: Text(t.translate('dark_mode')),
              value: settings.themeMode == ThemeMode.dark,
              activeColor: Colors.deepOrange,
              onChanged: settings.toggleTheme,
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.privacy_tip),
              title: Text(t.translate('privacy_policy')),
              trailing: Icon(Directionality.of(context) == TextDirection.rtl
                  ? Icons.chevron_left
                  : Icons.chevron_right),
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const PrivacyPolicyScreen())),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.receipt_long),
              title: Text(en ? 'Refund & Subscription Policy' : 'سياسة الاسترجاع والاشتراكات'),
              trailing: Icon(Directionality.of(context) == TextDirection.rtl
                  ? Icons.chevron_left
                  : Icons.chevron_right),
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const RefundPolicyScreen())),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.support_agent),
              title: Text(t.translate('support')),
              trailing: Icon(Directionality.of(context) == TextDirection.rtl
                  ? Icons.chevron_left
                  : Icons.chevron_right),
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const SupportScreen())),
            ),
          ),
        ],
        ),
      ),
    );
  }
}
