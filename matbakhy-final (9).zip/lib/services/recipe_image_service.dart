import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart' show consolidateHttpClientResponseBytes;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/recipe.dart';

/// صور الوصفات التي ليس لها صورة مضمّنة.
///
/// ترتيب الأولويات (من الأفضل للأضعف):
///   1) صورة المستخدم (يتولاها ImageManager)
///   2) صورة الوصفة المضمّنة في الـ assets (لو الحقل image غير فارغ)
///   3) نسخة محفوظة محلياً (Cache) من إنترنت — تُحمَّل مرة واحدة فقط
///   4) تحميل من TheMealDB بالمفتاح العام "1" (بدون تسجيل) حسب imageKeyword
///   5) صورة Asset محلية حسب التصنيف — خط الدفاع الأخير، لا يفشل أبداً
class RecipeImageService {
  RecipeImageService._();

  /// المفتاح "1" هو مفتاح الاختبار المجاني في TheMealDB (لا يحتاج حساب).
  static const String _api = 'https://www.themealdb.com/api/json/v1/1';
  static const Duration _timeout = Duration(seconds: 8);
  static const int _maxParallel = 3;
  static const Duration _offlinePause = Duration(seconds: 60);

  /// لو بحث الكلمة بالاسم (search.php?s=) رجّع صفراً، نجرّب تصنيف TheMealDB المقابل.
  static const Map<String, String> _mealDbCategory = {
    'chicken': 'Chicken',
    'beef': 'Beef',
    'stew': 'Lamb',
    'couscous': 'Lamb',
    'fish': 'Seafood',
    'pasta': 'Pasta',
    'dessert': 'Dessert',
    'cake': 'Dessert',
    'eggs': 'Breakfast',
    'bread': 'Breakfast',
    'oatmeal': 'Breakfast',
    'soup': 'Starter',
    'salad': 'Vegetarian',
    'pickle': 'Side',
    'vegetable': 'Vegetarian',
    'beans': 'Vegetarian',
    'rice': 'Side',
    'koshari': 'Vegetarian',
  };

  static const Set<String> _knownCategories = {
    'main', 'home', 'dessert', 'soups', 'heritage', 'pickles', 'baking', 'breakfast', 'salads',
  };

  // ------------------------------------------------------------ الـ Asset (خط الدفاع الأخير)

  /// مسار صورة الـ Asset الاحتياطية للوصفة (موجودة دائماً داخل التطبيق).
  static String fallbackAsset(Recipe r) {
    final c = _knownCategories.contains(r.category) ? r.category : 'default';
    return 'assets/images/fallback/$c.webp';
  }

  // ------------------------------------------------------------ الكاش المحلي

  static Directory? _dir;

  static Future<Directory> _cacheDir() async {
    final cached = _dir;
    if (cached != null) return cached;
    final base = await getApplicationSupportDirectory();
    final dir = Directory(p.join(base.path, 'recipe_images'));
    if (!await dir.exists()) await dir.create(recursive: true);
    return _dir = dir;
  }

  static Future<File> _fileFor(Recipe r) async {
    final dir = await _cacheDir();
    final safeId = r.id.replaceAll(RegExp(r'[^A-Za-z0-9_\-]'), '_');
    return File(p.join(dir.path, '$safeId.jpg'));
  }

  /// الصورة المحفوظة محلياً لو موجودة، وإلا null (لا يلمس الشبكة).
  static Future<File?> cachedFile(Recipe r) async {
    try {
      final f = await _fileFor(r);
      if (await f.exists() && await f.length() > 1024) return f;
    } catch (_) {}
    return null;
  }

  /// يحذف نسخة الكاش (مثلاً لو الملف تالف) ليُعاد تحميله لاحقاً.
  static Future<void> evict(Recipe r) async {
    try {
      final f = await _fileFor(r);
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }

  /// يمسح كل الصور المحفوظة (لزر "مسح الكاش" لو أضفته في الإعدادات).
  static Future<void> clearCache() async {
    try {
      final dir = await _cacheDir();
      if (await dir.exists()) {
        await dir.delete(recursive: true);
        await dir.create(recursive: true);
      }
      final prefs = await SharedPreferences.getInstance();
      for (final k in prefs.getKeys().where((k) => k.startsWith(_prefsPrefix)).toList()) {
        await prefs.remove(k);
      }
    } catch (_) {}
  }

  // ------------------------------------------------------------ التحميل

  static final Map<String, Future<File?>> _inflight = {};
  static final Map<String, DateTime> _failedAt = {};
  static const Duration _retryAfter = Duration(minutes: 30);

  /// يرجّع الملف من الكاش، أو يحمّله أول مرة ويحفظه. null = فشل (اعرض الـ Asset).
  /// آمن للنداء من عدة ويدجتس في نفس الوقت (الطلب الواحد لا يتكرر).
  static Future<File?> fetch(Recipe r) {
    final cached = _inflight[r.id];
    if (cached != null) return cached;
    final fut = _fetch(r).whenComplete(() => _inflight.remove(r.id));
    _inflight[r.id] = fut;
    return fut;
  }

  static Future<File?> _fetch(Recipe r) async {
    final hit = await cachedFile(r);
    if (hit != null) return hit;

    final failed = _failedAt[r.id];
    if (failed != null && DateTime.now().difference(failed) < _retryAfter) return null;
    if (_offlineUntil != null && DateTime.now().isBefore(_offlineUntil!)) return null;

    await _acquire();
    try {
      final urls = await _candidateUrls(r);
      if (urls.isEmpty) {
        _failedAt[r.id] = DateTime.now();
        return null;
      }
      // اختيار ثابت لكل وصفة (حتى تختلف الصور بين وصفات الكلمة الواحدة).
      final start = _stableHash(r.id) % urls.length;
      final target = await _fileFor(r);
      for (var i = 0; i < urls.length && i < 3; i++) {
        final url = urls[(start + i) % urls.length];
        final bytes = await _get(url);
        if (bytes == null || !_looksLikeImage(bytes)) continue;
        final tmp = File('${target.path}.tmp');
        await tmp.writeAsBytes(bytes, flush: true);
        await tmp.rename(target.path); // كتابة ذرّية: لا ملفات نصف مكتوبة
        return target;
      }
    } catch (_) {
      // أي خطأ → نرجع null والواجهة تعرض صورة الـ Asset
    } finally {
      _release();
    }
    _failedAt[r.id] = DateTime.now();
    return null;
  }

  static int _stableHash(String s) {
    var h = 17;
    for (final c in s.codeUnits) {
      h = (h * 31 + c) & 0x7fffffff;
    }
    return h;
  }

  // ------------------------------------------------------------ روابط TheMealDB

  static const String _prefsPrefix = 'mealdb_urls_';
  static final Map<String, List<String>> _urlMemo = {};

  /// قائمة روابط الصور المرشّحة للوصفة: بحث بالكلمة، ثم تصنيف احتياطي.
  static Future<List<String>> _candidateUrls(Recipe r) async {
    final key = r.imageKeyword.trim().toLowerCase();
    if (key.isEmpty) return const [];
    var urls = await _urlsFor('s:$key', '$_api/search.php?s=${Uri.encodeQueryComponent(key)}');
    if (urls.isEmpty) {
      final cat = _mealDbCategory[key];
      if (cat != null) urls = await _urlsFor('c:$cat', '$_api/filter.php?c=$cat');
    }
    return urls;
  }

  /// نتيجة كل بحث تُحفظ (ذاكرة + SharedPreferences): طلب API واحد لكل كلمة طوال عمر التطبيق.
  static Future<List<String>> _urlsFor(String cacheKey, String endpoint) async {
    final memo = _urlMemo[cacheKey];
    if (memo != null) return memo;

    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList('$_prefsPrefix$cacheKey');
    if (saved != null) return _urlMemo[cacheKey] = saved;

    final body = await _get(endpoint);
    if (body == null) return const []; // خطأ شبكة: لا نخزّن شيئاً لنعيد المحاولة لاحقاً
    try {
      final json = jsonDecode(utf8.decode(body));
      final meals = (json is Map ? json['meals'] : null);
      final urls = <String>[
        if (meals is List)
          for (final m in meals)
            if (m is Map && m['strMealThumb'] is String && (m['strMealThumb'] as String).startsWith('https://'))
              m['strMealThumb'] as String,
      ];
      await prefs.setStringList('$_prefsPrefix$cacheKey', urls); // حتى "لا نتائج" نخزّنها
      return _urlMemo[cacheKey] = urls;
    } catch (_) {
      return const [];
    }
  }

  // ------------------------------------------------------------ الشبكة (dart:io بدون حزم إضافية)

  static int _active = 0;
  static final List<Completer<void>> _waiters = [];
  static int _netFailures = 0;
  static DateTime? _offlineUntil;

  static Future<void> _acquire() async {
    if (_active < _maxParallel) {
      _active++;
      return;
    }
    final c = Completer<void>();
    _waiters.add(c);
    await c.future; // الدور انتقل إلينا بدون تغيير _active
  }

  static void _release() {
    if (_waiters.isNotEmpty) {
      _waiters.removeAt(0).complete();
    } else {
      _active--;
    }
  }

  static Future<List<int>?> _get(String url) async {
    final client = HttpClient()..connectionTimeout = _timeout;
    try {
      final req = await client.getUrl(Uri.parse(url)).timeout(_timeout);
      req.headers.set(HttpHeaders.userAgentHeader, 'Matbakhy/1.0');
      final res = await req.close().timeout(_timeout);
      if (res.statusCode != 200) {
        await res.drain<void>();
        return null;
      }
      final bytes = await consolidateHttpClientResponseBytes(res).timeout(const Duration(seconds: 20));
      _netFailures = 0;
      _offlineUntil = null;
      return bytes;
    } catch (_) {
      // 3 أخطاء شبكة متتالية = غالباً لا يوجد إنترنت → نتوقف دقيقة بدل إغراق الشبكة.
      if (++_netFailures >= 3) {
        _offlineUntil = DateTime.now().add(_offlinePause);
        _netFailures = 0;
      }
      return null;
    } finally {
      client.close(force: true);
    }
  }

  /// يتأكد أن الرد صورة حقاً (JPEG/PNG/WebP) وليس صفحة خطأ HTML.
  static bool _looksLikeImage(List<int> b) {
    if (b.length < 1024) return false;
    final jpg = b[0] == 0xFF && b[1] == 0xD8;
    final png = b[0] == 0x89 && b[1] == 0x50;
    final webp = b[0] == 0x52 && b[1] == 0x49 && b[2] == 0x46 && b[3] == 0x46;
    return jpg || png || webp;
  }
}
