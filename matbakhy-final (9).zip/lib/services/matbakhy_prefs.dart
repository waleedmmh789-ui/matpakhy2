import 'package:shared_preferences/shared_preferences.dart';

/// حالة التطبيق والعدادات المحفوظة محلياً (مرآة لكلاس MatbakhyPrefs المطلوب في المواصفات).
/// كل القيم تُقرأ وتُكتب عبر هذا الكلاس فقط حتى تبقى المفاتيح في مكان واحد.
class MatbakhyPrefs {
  MatbakhyPrefs._(this._p);
  final SharedPreferences _p;

  static Future<MatbakhyPrefs> load() async => MatbakhyPrefs._(await SharedPreferences.getInstance());

  bool get isSubscribed =>
      _p.getBool('is_subscribed') ?? _p.getBool('isPremiumUser') ?? false; // الثاني: مفتاح النسخ القديمة
  set isSubscribed(bool v) => _p.setBool('is_subscribed', v);

  int get calculatorRemainingUses => _p.getInt('calc_remaining_uses') ?? 0;
  set calculatorRemainingUses(int v) => _p.setInt('calc_remaining_uses', v < 0 ? 0 : v);

  int get recipeOpenCounter => _p.getInt('recipe_open_counter') ?? 0;
  set recipeOpenCounter(int v) => _p.setInt('recipe_open_counter', v);

  int get timerUseCounter => _p.getInt('timer_use_counter') ?? 0;
  set timerUseCounter(int v) => _p.setInt('timer_use_counter', v);

  bool get hasShownCountryAd => _p.getBool('has_shown_country_ad') ?? false;
  set hasShownCountryAd(bool v) => _p.setBool('has_shown_country_ad', v);

  bool get hasRatedApp => _p.getBool('has_rated_app') ?? false;
  set hasRatedApp(bool v) => _p.setBool('has_rated_app', v);

  int get lastRatingPromptMillis => _p.getInt('last_rating_prompt_millis') ?? 0;
  set lastRatingPromptMillis(int v) => _p.setInt('last_rating_prompt_millis', v);
}
