import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:provider/provider.dart';
import '../ads/ad_config.dart';
import '../ads/ad_service.dart';
import '../providers/premium_provider.dart';

/// بانر ثابت (Adaptive). لا يظهر ولا يُحمَّل أصلاً للمشتركين.
class BannerAdWidget extends StatefulWidget {
  final String? adUnitId;
  const BannerAdWidget({super.key, this.adUnitId});

  @override
  State<BannerAdWidget> createState() => _BannerAdWidgetState();
}

class _BannerAdWidgetState extends State<BannerAdWidget> {
  BannerAd? _ad;
  bool _loading = false;
  int? _loadedWidth;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final premium = context.watch<PremiumProvider>();
    if (!premium.loaded || premium.isPremium) {
      _disposeAd();
      return;
    }
    final width = MediaQuery.sizeOf(context).width.truncate();
    if (_ad == null && !_loading || _loadedWidth != width) _load(width);
  }

  Future<void> _load(int width) async {
    if (_loading || !AdService.instance.canShowAds) return;
    _loading = true;
    final size = await AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(width);
    if (!mounted || size == null) {
      _loading = false;
      return;
    }
    _disposeAd();
    final ad = BannerAd(
      adUnitId: widget.adUnitId ?? AdConfig.banner,
      size: size,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (a) {
          _loading = false;
          if (!mounted) {
            a.dispose();
            return;
          }
          setState(() {
            _ad = a as BannerAd;
            _loadedWidth = width;
          });
        },
        onAdFailedToLoad: (a, e) {
          a.dispose();
          _loading = false;
          debugPrint('Banner failed: $e');
        },
      ),
    );
    await ad.load();
  }

  void _disposeAd() {
    _ad?.dispose();
    _ad = null;
    _loadedWidth = null;
  }

  @override
  void dispose() {
    _ad?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final premium = context.watch<PremiumProvider>();
    final ad = _ad;
    if (!premium.loaded || premium.isPremium || ad == null) return const SizedBox.shrink();
    return SizedBox(
      width: ad.size.width.toDouble(),
      height: ad.size.height.toDouble(),
      child: AdWidget(ad: ad),
    );
  }
}
