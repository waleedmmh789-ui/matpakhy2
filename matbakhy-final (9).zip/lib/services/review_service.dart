import 'package:flutter/material.dart';
import '../localization/app_localizations.dart';
import 'package:in_app_review/in_app_review.dart';
import 'matbakhy_prefs.dart';

/// طلب تقييم التطبيق عند فتحه:
/// - مرة واحدة كل [intervalDays] أيام كحد أقصى (يُحفظ وقت آخر ظهور).
/// - لو ضغط المستخدم «قيّم التطبيق الآن» تُحفظ الحالة (hasRatedApp) ولا تظهر النافذة أبداً بعدها.
/// - زر «لاحقاً» أو إغلاق النافذة لا يمنع ظهورها بعد [intervalDays] أيام.
/// - لا نقدم أي مكافأة مقابل التقييم (سياسة Google Play).
/// - نافذة التقييم الرسمية تُعرض عبر Play In-App Review API، وإن لم تتوفر نفتح صفحة التطبيق.
///   Google هي من تقرر ظهور النافذة فعلاً (حصة محدودة)، لذلك لا يمكن ضمان ظهورها في كل مرة.
class ReviewService {
  ReviewService._();

  static const int intervalDays = 3;

  /// false = المستخدم الجديد لا يرى النافذة في أول فتح، بل بعد [intervalDays] أيام.
  /// غيّرها إلى true لو تريدها تظهر من أول تشغيل.
  static const bool showOnFirstLaunch = false;

  static bool _busy = false;

  /// يُستدعى مرة عند فتح التطبيق (بعد إعلان فتح التطبيق إن وُجد).
  static Future<void> maybePromptOnLaunch(BuildContext context) async {
    if (_busy) return;
    final prefs = await MatbakhyPrefs.load();
    if (prefs.hasRatedApp) return;

    final now = DateTime.now().millisecondsSinceEpoch;
    final last = prefs.lastRatingPromptMillis;
    if (last == 0 && !showOnFirstLaunch) {
      prefs.lastRatingPromptMillis = now; // نبدأ العدّ من أول فتح
      return;
    }
    if (last != 0 && now - last < const Duration(days: intervalDays).inMilliseconds) return;
    if (!context.mounted) return;

    _busy = true;
    try {
      prefs.lastRatingPromptMillis = now; // نسجل عند الظهور حتى لا تتكرر قبل 3 أيام
      final rateNow = await showDialog<bool>(
        context: context,
        builder: (_) => const _ReviewPrePrompt(),
      );
      if (rateNow == true) {
        prefs.hasRatedApp = true; // لن تظهر النافذة مرة أخرى أبداً
        await _launchReview();
      }
    } finally {
      _busy = false;
    }
  }

  static Future<void> _launchReview() async {
    final review = InAppReview.instance;
    try {
      if (await review.isAvailable()) {
        await review.requestReview(); // نافذة Google Play الرسمية (ReviewManager)
      } else {
        await review.openStoreListing(); // بديل: صفحة التطبيق على Google Play
      }
    } catch (_) {
      try {
        await review.openStoreListing();
      } catch (_) {}
    }
  }
}

/// الشاشة التمهيدية قبل نافذة التقييم الرسمية.
class _ReviewPrePrompt extends StatelessWidget {
  const _ReviewPrePrompt();

  static const _orange = Color(0xFFFF6B35);

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
      insetPadding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 28, 24, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),
                boxShadow: [
                  BoxShadow(
                    color: _orange.withValues(alpha: 0.35),
                    blurRadius: 18,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(22),
                child: Image.asset('assets/icon/icon.png', width: 88, height: 88, fit: BoxFit.cover),
              ),
            ),
            const SizedBox(height: 18),
            Text(isEnLocale(context) ? 'We value your opinion' : 'رأيك يهمنا',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text(
              isEnLocale(context)
                  ? 'Are you enjoying "Matbakhy - Recipes & Calorie Calculator"? '
                      'Your rating on Google Play helps us improve and add more recipes.'
                  : 'هل استمتعت باستخدام «مطبخي - وصفات وحاسبة سعرات»؟ '
                      'تقييمك على Google Play يساعدنا على التطوير وإضافة وصفات أكثر.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 15, height: 1.7, color: scheme.onSurfaceVariant),
            ),
            const SizedBox(height: 22),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: _orange,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                onPressed: () => Navigator.pop(context, true),
                child: Text(isEnLocale(context) ? 'Rate the app now' : 'قيّم التطبيق الآن',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 4),
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: Text(isEnLocale(context) ? 'Later' : 'لاحقاً'),
            ),
          ],
        ),
      ),
    );
  }
}
