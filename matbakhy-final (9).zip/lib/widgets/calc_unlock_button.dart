import 'package:flutter/material.dart';
import '../localization/app_localizations.dart';
import 'package:provider/provider.dart';
import '../ads/ad_service.dart';
import '../providers/premium_provider.dart';

/// زر الإعلان المكافئ للحاسبة: «شاهد إعلاناً للحصول على 3 استخدامات للحاسبة».
/// يظهر فقط حين ينتهي رصيد الاستخدامات، ومخفي للمشتركين.
class CalcUnlockButton extends StatelessWidget {
  const CalcUnlockButton({super.key});

  @override
  Widget build(BuildContext context) {
    final premium = context.watch<PremiumProvider>();
    if (!premium.loaded || premium.isPremium || premium.calcRemainingUses > 0) {
      return const SizedBox.shrink();
    }
    final n = PremiumProvider.calcUsesPerReward;
    return OutlinedButton.icon(
      icon: const Icon(Icons.play_circle_outline),
      label: Text(isEnLocale(context)
          ? 'Watch an ad to get $n calculator uses'
          : 'شاهد إعلاناً للحصول على $n استخدامات للحاسبة'),
      style: OutlinedButton.styleFrom(foregroundColor: Colors.deepOrange),
      onPressed: () {
        final en = isEnLocale(context);
        final messenger = ScaffoldMessenger.of(context);
        AdService.instance.showRewarded(
          onReward: () {
            premium.grantCalcUses();
            messenger.showSnackBar(SnackBar(
              content: Text(en
                  ? '$n calculator uses added 🎉'
                  : 'تمت إضافة $n استخدامات للحاسبة 🎉'),
            ));
          },
          onUnavailable: () => messenger.showSnackBar(SnackBar(
            content: Text(en ? 'The ad is not ready now, try again shortly.' : 'الإعلان غير جاهز الآن، حاول بعد قليل.'),
          )),
        );
      },
    );
  }
}
