import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../providers/premium_provider.dart';
import '../services/matbakhy_prefs.dart';
import 'ad_config.dart';

/// كل استدعاءات الإعلانات تمر من هنا، وكلها تتحقق أولاً من canShowAds:
/// المشترك لا يرى أي إعلان (فتح التطبيق/بانر/بيني/مكافئ) نهائياً.
class AdService {
  AdService._();
  static final AdService instance = AdService._();

  /// بيني واحد بعد كل N وصفات تُفتح.
  static const int recipeInterstitialEvery = 3;

  /// بيني واحد بعد كل N مرات تشغيل للمؤقت.
  static const int timerInterstitialEvery = 5;

  /// يضبطه main.dart بنتيجة MobileAds.initialize() لننتظرها قبل طلب إعلان فتح التطبيق.
  Future<InitializationStatus>? initFuture;

  PremiumProvider? _premium;
  InterstitialAd? _interstitial;
  RewardedAd? _rewarded;
  AppOpenAd? _appOpen;
  bool _loadingInterstitial = false;
  bool _loadingRewarded = false;
  bool _appOpenHandled = false;

  /// القاعدة الذهبية: لا إعلانات قبل تحميل حالة الاشتراك، ولا للمشتركين.
  bool get canShowAds => _premium != null && _premium!.loaded && !_premium!.isPremium;

  void attach(PremiumProvider premium) {
    _premium = premium;
    premium.addListener(_onPremiumChanged);
  }

  void _onPremiumChanged() {
    if (canShowAds) {
      _loadInterstitial();
      _loadRewarded();
    } else {
      // أي اشتراك فعّال يوقف كل الإعلانات فوراً ويُفرّغ ما حُمّل مسبقاً.
      _interstitial?.dispose();
      _interstitial = null;
      _rewarded?.dispose();
      _rewarded = null;
      _appOpen?.dispose();
      _appOpen = null;
    }
  }

  // ---------- App Open ----------
  /// يُستدعى مرة واحدة عند فتح التطبيق. ينتظر حالة الاشتراك، ثم يعرض الإعلان إن جهز خلال
  /// ثوانٍ قليلة (حتى لا نؤخر المستخدم). يرجع بعد إغلاق الإعلان أو فوراً إن لم يُعرض.
  Future<void> showAppOpenOnLaunch() async {
    if (_appOpenHandled) return;
    _appOpenHandled = true;

    // انتظار تحميل حالة الاشتراك (حتى 3 ثوانٍ).
    for (var i = 0; i < 30 && !(_premium?.loaded ?? false); i++) {
      await Future<void>.delayed(const Duration(milliseconds: 100));
    }
    if (!canShowAds || AdConfig.appOpen.isEmpty) return;

    try {
      await initFuture?.timeout(const Duration(seconds: 4));
    } catch (_) {}

    final ad = await _loadAppOpen();
    if (ad == null) return;
    if (!canShowAds) {
      ad.dispose();
      return;
    }
    _appOpen = ad;
    final done = Completer<void>();
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (a) {
        a.dispose();
        _appOpen = null;
        if (!done.isCompleted) done.complete();
      },
      onAdFailedToShowFullScreenContent: (a, e) {
        a.dispose();
        _appOpen = null;
        if (!done.isCompleted) done.complete();
      },
    );
    ad.show();
    await done.future;
  }

  Future<AppOpenAd?> _loadAppOpen() {
    final c = Completer<AppOpenAd?>();
    var timedOut = false;
    AppOpenAd.load(
      adUnitId: AdConfig.appOpen,
      request: const AdRequest(),
      adLoadCallback: AppOpenAdLoadCallback(
        onAdLoaded: (ad) {
          if (timedOut) {
            ad.dispose(); // وصل متأخراً بعد أن تجاوزنا الانتظار
          } else if (!c.isCompleted) {
            c.complete(ad);
          }
        },
        onAdFailedToLoad: (e) {
          debugPrint('AppOpen failed: $e');
          if (!c.isCompleted) c.complete(null);
        },
      ),
    );
    return c.future.timeout(const Duration(seconds: 5), onTimeout: () {
      timedOut = true;
      return null;
    });
  }

  // ---------- Interstitial ----------
  void _loadInterstitial() {
    if (!canShowAds || _interstitial != null || _loadingInterstitial) return;
    _loadingInterstitial = true;
    InterstitialAd.load(
      adUnitId: AdConfig.interstitial,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _loadingInterstitial = false;
          if (canShowAds) {
            _interstitial = ad;
          } else {
            ad.dispose();
          }
        },
        onAdFailedToLoad: (e) {
          _loadingInterstitial = false;
          debugPrint('Interstitial failed: $e');
        },
      ),
    );
  }

  /// يعرض البيني لو جاهز. يرجع true لو عُرض (وسيُستدعى [proceed] بعد إغلاقه)،
  /// وfalse لو لم يكن جاهزاً (والمستدعي يكمل بنفسه).
  bool _tryShowInterstitial(VoidCallback proceed) {
    final ad = _interstitial;
    if (ad == null || !canShowAds) {
      if (ad == null) _loadInterstitial();
      return false;
    }
    _interstitial = null;
    var done = false;
    void go() {
      if (done) return;
      done = true;
      proceed();
    }

    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (a) {
        a.dispose();
        _loadInterstitial();
        go();
      },
      onAdFailedToShowFullScreenContent: (a, e) {
        a.dispose();
        _loadInterstitial();
        go();
      },
    );
    ad.show();
    return true;
  }

  /// فتح وصفة: بيني بعد كل [recipeInterstitialEvery] وصفات (العداد: 1، 2، إعلان عند 3، ثم يُصفَّر).
  /// لو الإعلان لم يكن جاهزاً عند الدور، يبقى العداد عند 3 ويُحاول في الفتحة التالية.
  /// [categoryAd]: المستخدم اختار تصنيفاً وهذا أول دخول لوصفة بعد اختياره → بيني الآن.
  Future<void> maybeShowInterstitial(VoidCallback proceed, {bool categoryAd = false}) async {
    if (!canShowAds) {
      proceed();
      return;
    }
    final prefs = await MatbakhyPrefs.load();
    final count = prefs.recipeOpenCounter + 1;
    final due = count >= recipeInterstitialEvery || categoryAd;
    if (due && _tryShowInterstitial(proceed)) {
      prefs.recipeOpenCounter = 0;
      return;
    }
    prefs.recipeOpenCounter = count > recipeInterstitialEvery ? recipeInterstitialEvery : count;
    if (_interstitial == null) _loadInterstitial();
    proceed();
  }

  /// المؤقت: بيني بعد كل [timerInterstitialEvery] مرات تشغيل، ثم يبدأ المؤقت عبر [proceed].
  Future<void> maybeShowTimerInterstitial(VoidCallback proceed) async {
    if (!canShowAds) {
      proceed();
      return;
    }
    final prefs = await MatbakhyPrefs.load();
    final count = prefs.timerUseCounter + 1;
    if (count >= timerInterstitialEvery && _tryShowInterstitial(proceed)) {
      prefs.timerUseCounter = 0;
      return;
    }
    prefs.timerUseCounter = count > timerInterstitialEvery ? timerInterstitialEvery : count;
    if (_interstitial == null) _loadInterstitial();
    proceed();
  }

  /// اختيار دولة/مطبخ: بيني مرة واحدة فقط طوال عمر التثبيت (الحالة محفوظة محلياً).
  /// لا نعلّمه "ظهر" إلا لو عُرض فعلاً.
  Future<void> maybeShowCountryInterstitial() async {
    if (!canShowAds) return;
    final prefs = await MatbakhyPrefs.load();
    if (prefs.hasShownCountryAd) return;
    if (_tryShowInterstitial(() {})) prefs.hasShownCountryAd = true;
  }

  // ---------- Rewarded ----------
  void _loadRewarded() {
    if (!canShowAds || _rewarded != null || _loadingRewarded) return;
    _loadingRewarded = true;
    RewardedAd.load(
      adUnitId: AdConfig.rewarded,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _loadingRewarded = false;
          if (canShowAds) {
            _rewarded = ad;
          } else {
            ad.dispose();
          }
        },
        onAdFailedToLoad: (e) {
          _loadingRewarded = false;
          debugPrint('Rewarded failed: $e');
        },
      ),
    );
  }

  /// يعرض الإعلان المكافئ؛ يستدعي [onReward] فقط لو المستخدم أكمل المشاهدة،
  /// و[onUnavailable] لو الإعلان غير جاهز.
  void showRewarded({required VoidCallback onReward, required VoidCallback onUnavailable}) {
    final ad = _rewarded;
    if (!canShowAds || ad == null) {
      _loadRewarded();
      onUnavailable();
      return;
    }
    _rewarded = null;
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (a) {
        a.dispose();
        _loadRewarded();
      },
      onAdFailedToShowFullScreenContent: (a, e) {
        a.dispose();
        _loadRewarded();
        onUnavailable();
      },
    );
    ad.show(onUserEarnedReward: (_, __) => onReward());
  }
}
