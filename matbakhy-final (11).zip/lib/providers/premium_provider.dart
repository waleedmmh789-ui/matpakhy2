import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import '../services/matbakhy_prefs.dart';

/// معرّف منتج الاشتراك السنوي — لازم يطابق Product ID في Google Play Console.
const String kPremiumProductId = 'matbakhy_premium_yearly';

/// معرّف الاشتراك الشهري — اشتراك منفصل في Play Console.
const String kMonthlyProductId = 'matbakhy_premium_monthly';

/// معرّف الاشتراك الأسبوعي — اشتراك منفصل في Play Console.
const String kWeeklyProductId = 'matbakhy_premium_weekly';

/// كل المنتجات التي تفتح النسخة المميزة.
const Set<String> kPremiumProductIds = {kPremiumProductId, kMonthlyProductId, kWeeklyProductId};

/// السعر الاحتياطي الأسبوعي الظاهر لو تعذر جلب السعر من المتجر.
const String kWeeklyPriceLabel = '\$0.99 / أسبوع';

/// السعر الاحتياطي الشهري الظاهر لو تعذر جلب السعر من المتجر.
const String kMonthlyPriceLabel = '\$1.99 / شهر';

/// السعر الاحتياطي الظاهر لو تعذر جلب السعر من المتجر. عدّله براحتك.
const String kYearlyPriceLabel = '\$9.99 / سنة';

/// حالة الاشتراك (أسبوعي/شهري/سنوي) + رصيد استخدامات حاسبة السعرات (3 استخدامات لكل إعلان مكافئ).
class PremiumProvider extends ChangeNotifier {
  /// عدد استخدامات الحاسبة التي يفتحها كل إعلان مكافئ.
  static const int calcUsesPerReward = 3;

  /// استخدامات مجانية تُمنح عند أول تشغيل: يجرّب المستخدم الحاسبة أولاً ثم يظهر طلب الإعلان.
  static const int calcFreeUses = 3;

  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _sub;

  bool _loaded = false;
  bool _isPremium = false;
  bool _storeAvailable = false;
  bool _busy = false;
  bool _startupCheck = false;
  String? _message;
  ProductDetails? _yearly;
  ProductDetails? _monthly;
  ProductDetails? _weekly;

  int _calcRemaining = 0;

  bool get loaded => _loaded;
  bool get isPremium => _isPremium;
  bool get storeAvailable => _storeAvailable;
  bool get busy => _busy;
  String? get message => _message;
  ProductDetails? get yearlyProduct => _yearly;
  ProductDetails? get monthlyProduct => _monthly;
  ProductDetails? get weeklyProduct => _weekly;
  bool get hasProducts => _yearly != null || _monthly != null || _weekly != null;

  String get yearlyPriceLabel => _yearly != null ? '${_yearly!.price} / سنة' : kYearlyPriceLabel;
  String get monthlyPriceLabel => _monthly != null ? '${_monthly!.price} / شهر' : kMonthlyPriceLabel;
  String get weeklyPriceLabel => _weekly != null ? '${_weekly!.price} / أسبوع' : kWeeklyPriceLabel;

  ProductDetails? productFor(String id) =>
      id == kMonthlyProductId ? _monthly : (id == kWeeklyProductId ? _weekly : _yearly);

  /// نسبة التوفير للسنوي مقارنةً بـ 12 شهراً (للعرض فقط)، أو null لو غير متاحة.
  int? get yearlySavingPercent {
    if (_yearly == null || _monthly == null) return null;
    final y = _yearly!.rawPrice, m = _monthly!.rawPrice * 12;
    if (m <= 0 || y >= m) return null;
    return ((1 - y / m) * 100).round();
  }

  /// الحاسبة مفتوحة للمشترك دائماً، ولغيره ما دام لديه رصيد استخدامات.
  bool get canUseCalculator => _isPremium || _calcRemaining > 0;
  int get calcRemainingUses => _calcRemaining;

  Future<void> load() async {
    final prefs = await MatbakhyPrefs.load();
    _isPremium = prefs.isSubscribed;
    if (!prefs.calcInitialGranted) {
      prefs.calcInitialGranted = true;
      prefs.calculatorRemainingUses = calcFreeUses;
    }
    _calcRemaining = prefs.calculatorRemainingUses;
    _loaded = true;
    notifyListeners();
    await _initStore();
  }

  Future<void> _initStore() async {
    try {
      _sub = _iap.purchaseStream.listen(_onPurchases, onError: (_) {});
      _storeAvailable = await _iap.isAvailable();
      if (!_storeAvailable) {
        notifyListeners();
        return;
      }
      final res = await _iap.queryProductDetails(kPremiumProductIds);
      for (final d in res.productDetails) {
        if (d.id == kPremiumProductId) _yearly = d;
        if (d.id == kMonthlyProductId) _monthly = d;
        if (d.id == kWeeklyProductId) _weekly = d;
      }
      notifyListeners();
      // تحقق صامت من الاشتراك عند الإقلاع (يلتقط الانتهاء/الإلغاء لو المتجر ردّ).
      _startupCheck = true;
      await _iap.restorePurchases();
    } catch (_) {
      _storeAvailable = false;
      notifyListeners();
    }
  }

  Future<void> _setPremium(bool v) async {
    if (_isPremium == v) return;
    _isPremium = v;
    notifyListeners();
    (await MatbakhyPrefs.load()).isSubscribed = v;
  }

  Future<void> _onPurchases(List<PurchaseDetails> list) async {
    var foundActive = false;
    for (final p in list) {
      if (kPremiumProductIds.contains(p.productID)) {
        switch (p.status) {
          case PurchaseStatus.pending:
            _busy = true;
            break;
          case PurchaseStatus.purchased:
          case PurchaseStatus.restored:
            foundActive = true;
            _busy = false;
            _message = null;
            await _setPremium(true);
            break;
          case PurchaseStatus.error:
            _busy = false;
            _message = 'تعذر إتمام الشراء. حاول مرة أخرى.';
            break;
          case PurchaseStatus.canceled:
            _busy = false;
            break;
        }
      }
      if (p.pendingCompletePurchase) await _iap.completePurchase(p);
    }
    if (_startupCheck) {
      _startupCheck = false;
      // رد المتجر على الاستعادة ما فيهوش اشتراك فعّال → الاشتراك انتهى/اتلغى.
      if (!foundActive && list.every((p) => p.status != PurchaseStatus.pending)) {
        await _setPremium(false);
      }
    }
    notifyListeners();
  }

  /// شراء اشتراك: [kWeeklyProductId] أسبوعي أو [kMonthlyProductId] شهري أو [kPremiumProductId] سنوي.
  Future<void> buy(String productId) async {
    final product = productFor(productId);
    if (product == null || _busy) return;
    _message = null;
    _busy = true;
    notifyListeners();
    try {
      await _iap.buyNonConsumable(purchaseParam: PurchaseParam(productDetails: product));
    } catch (_) {
      _busy = false;
      _message = 'تعذر بدء عملية الشراء.';
      notifyListeners();
    }
  }

  /// استعادة المشتريات (إجباري من جوجل).
  Future<void> restore() async {
    if (!_storeAvailable || _busy) return;
    _message = null;
    _busy = true;
    notifyListeners();
    try {
      await _iap.restorePurchases();
    } catch (_) {
      _message = 'تعذر استعادة المشتريات.';
    }
    // لو ما وصلش رد خلال ثوانٍ نفك حالة الانتظار ونبلّغ المستخدم.
    Future.delayed(const Duration(seconds: 6), () {
      if (_busy) {
        _busy = false;
        _message ??= _isPremium ? null : 'لم نجد اشتراكاً فعّالاً على هذا الحساب.';
        notifyListeners();
      }
    });
  }

  // ---- حاسبة السعرات ----
  /// يُستدعى بعد كل حساب ناجح: يخصم استخداماً واحداً من الرصيد (المشترك لا يُخصم منه).
  Future<void> registerCalcUse() async {
    if (_isPremium || _calcRemaining <= 0) return;
    _calcRemaining--;
    notifyListeners();
    (await MatbakhyPrefs.load()).calculatorRemainingUses = _calcRemaining;
  }

  /// مكافأة الإعلان: رصيد جديد من [calcUsesPerReward] استخدامات.
  Future<void> grantCalcUses() async {
    _calcRemaining = calcUsesPerReward;
    notifyListeners();
    (await MatbakhyPrefs.load()).calculatorRemainingUses = _calcRemaining;
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}
