import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../localization/app_localizations.dart';
import '../models/recipe.dart';
import '../ads/ad_service.dart';
import '../providers/favorites_provider.dart';
import '../providers/premium_provider.dart';
import '../providers/recipes_provider.dart';
import 'meal_plan_tab.dart';
import 'premium_screen.dart';
import 'nutrition_calculator_screen.dart';
import 'ramadan_screen.dart';
import '../widgets/language_switch.dart';
import 'recipe_screen.dart';
import 'settings_screen.dart';
import 'shopping_tab.dart';
import '../widgets/banner_ad_widget.dart';
import '../widgets/health_disclaimer.dart';
import '../services/review_service.dart';
import '../widgets/recipe_image.dart';
import '../widgets/responsive_body.dart';

bool isEnglish(BuildContext c) => Localizations.localeOf(c).languageCode == 'en';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;
  String _query = '';
  String? _cuisine; // بالعربي؛ null = الكل
  String? _category; // مفتاح التصنيف؛ null = الكل
  bool _categoryAdPending = false; // اختار المستخدم تصنيفاً → بيني عند أول دخول وصفة

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _onLaunch());
  }

  /// عند فتح التطبيق: إعلان فتح التطبيق أولاً (للمستخدم غير المشترك)، ثم نافذة التقييم لو حان وقتها.
  Future<void> _onLaunch() async {
    await AdService.instance.showAppOpenOnLaunch();
    if (!mounted) return;
    await ReviewService.maybePromptOnLaunch(context);
  }

  List<Recipe> _visible(List<Recipe> all, FavoritesProvider fav) {
    final q = _query.trim().toLowerCase();
    return all.where((r) {
      if (_tab == 1 && !fav.isFavorite(r.id)) return false;
      if (_cuisine != null && r.cuisineAr != _cuisine) return false;
      if (_category != null && r.category != _category) return false;
      if (q.isNotEmpty && !r.searchText.contains(q)) return false;
      return true;
    }).toList();
  }

  void _open(Recipe r) {
    // بيني كل 3 وصفات، أو عند أول وصفة بعد اختيار تصنيف (ولا يظهر للمشترك)، ثم تُفتح الوصفة.
    final categoryAd = _categoryAdPending;
    _categoryAdPending = false;
    AdService.instance.maybeShowInterstitial(() {
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => RecipeScreen(recipe: r)));
    }, categoryAd: categoryAd);
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final data = context.watch<RecipesProvider>();
    final premium = context.watch<PremiumProvider>();

    return Scaffold(
      appBar: AppBar(
        leadingWidth: 96,
        leading: const LanguageSwitch(),
        title: Text(t.translate('app_title'), style: const TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        actions: [
          if (!premium.isPremium)
            IconButton(
              tooltip: isEnglish(context) ? 'Remove ads' : 'إزالة الإعلانات',
              icon: const Text('👑', style: TextStyle(fontSize: 20)),
              onPressed: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const PremiumScreen())),
            ),
          IconButton(
            tooltip: isEnglish(context) ? kCalcDisclaimerTitleEn : kCalcDisclaimerTitle,
            icon: const Icon(Icons.warning_amber_rounded, color: Color(0xFFFFB300)),
            onPressed: () => showHealthDisclaimer(context),
          ),
          IconButton(
            icon: const Icon(Icons.calculate),
            tooltip: t.translate('nutrition_calculator'),
            onPressed: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const NutritionCalculatorScreen())),
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            tooltip: t.translate('settings'),
            onPressed: () =>
                Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
        ],
      ),
      body: ResponsiveBody(
        maxWidth: 1100,
        safeBottom: false, // الـ NavigationBar بيتعامل مع الحافة السفلية
        child: data.loading
            ? const Center(child: CircularProgressIndicator())
            : data.error != null
                ? Center(child: Text(t.translate('load_error')))
                : _body(context, data),
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const BannerAdWidget(),
          NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (v) => setState(() => _tab = v),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.restaurant_menu), label: t.translate('nav_recipes')),
          NavigationDestination(icon: const Icon(Icons.favorite), label: t.translate('favorites')),
          NavigationDestination(icon: const Icon(Icons.shopping_cart), label: t.translate('shopping_list')),
          NavigationDestination(icon: const Icon(Icons.calendar_month), label: t.translate('nav_meal')),
        ],
      ),
        ],
      ),
    );
  }

  Widget _body(BuildContext context, RecipesProvider data) {
    if (_tab == 2) return const ShoppingTab();
    if (_tab == 3) return const MealPlanTab();

    final t = AppLocalizations.of(context);
    final en = isEnglish(context);
    final fav = context.watch<FavoritesProvider>();
    final list = _visible(data.recipes, fav);

    // المطابخ والتصنيفات الموجودة فعلاً في البيانات
    final cuisines = <String, String>{}; // ar -> en
    for (final r in data.recipes) {
      cuisines.putIfAbsent(r.cuisineAr, () => r.cuisineEn);
    }
    final categories = data.recipes.map((r) => r.category).toSet().toList()..sort();

    return Column(
      children: [
        if (_tab == 0) ...[
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text(t.translate('calc_card_title'),
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
          ),
          InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const NutritionCalculatorScreen())),
            child: Container(
              width: double.infinity,
              margin: const EdgeInsets.fromLTRB(16, 6, 16, 8),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFFFF7043), Color(0xFFD84315)]),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Row(
                children: [
                  const Icon(Icons.calculate, color: Colors.white, size: 44),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(t.translate('calc_card_line1'),
                            style: const TextStyle(
                                color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                        Text(t.translate('calc_card_line2'),
                            style: const TextStyle(color: Colors.white70)),
                      ],
                    ),
                  ),
                  IconButton(
                    tooltip: t.translate('surprise'),
                    icon: const Icon(Icons.casino, color: Colors.white),
                    onPressed: () {
                      final pool = List<Recipe>.of(list.isEmpty ? data.recipes : list)..shuffle();
                      if (pool.isNotEmpty) _open(pool.first);
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: TextField(
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search),
              hintText: t.translate('search_hint'),
              filled: true,
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
            ),
            onChanged: (v) => setState(() => _query = v),
          ),
        ),
        _chips(
          [
            (null, t.translate('all')),
            for (final e in cuisines.entries) (e.key, en ? e.value : e.key),
          ],
          _cuisine,
          (v) {
            setState(() => _cuisine = v);
            // اختيار دولة: بيني مرة واحدة فقط طوال عمر التثبيت (الحالة محفوظة محلياً).
            if (v != null) AdService.instance.maybeShowCountryInterstitial();
          },
          after: (value) => value == 'تونسي'
              ? Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: ActionChip(
                    avatar: const Text('🌙'),
                    label: Text(en ? 'Ramadan Plan' : 'جدول رمضان',
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    onPressed: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const RamadanScreen())),
                  ),
                )
              : null,
        ),
        _chips(
          [
            (null, t.translate('all')),
            for (final c in categories) (c, t.translate('cat_$c')),
          ],
          _category,
          (v) => setState(() {
            _category = v;
            _categoryAdPending = v != null;
          }),
        ),
        Expanded(
          child: list.isEmpty
              ? Center(child: Text(_tab == 1 ? t.translate('no_favorites') : t.translate('no_results')))
              : GridView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: list.length,
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 230, // عمودين في الموبايل وأكتر في التابلت
                    childAspectRatio: .67,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                  ),
                  itemBuilder: (context, i) => _RecipeCard(recipe: list[i], onTap: () => _open(list[i])),
                ),
        ),
      ],
    );
  }

  Widget _chips(List<(String?, String)> items, String? selected, ValueChanged<String?> onSel,
      {Widget? Function(String? value)? after}) {
    return SizedBox(
      height: 52,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        children: [
          for (final (value, label) in items) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: ChoiceChip(
                label: Text(label),
                selected: selected == value,
                onSelected: (_) => onSel(value),
              ),
            ),
            if (after != null && after(value) != null) after(value)!,
          ],
        ],
      ),
    );
  }
}

class _RecipeCard extends StatelessWidget {
  final Recipe recipe;
  final VoidCallback onTap;
  const _RecipeCard({required this.recipe, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final en = isEnglish(context);
    final fav = context.watch<FavoritesProvider>();
    final isFav = fav.isFavorite(recipe.id);
    final meta = [
      '${recipe.flag} ${recipe.cuisine(en)}',
      if (recipe.time(en).isNotEmpty) recipe.time(en),
    ].join(' · ');

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Card(
        clipBehavior: Clip.antiAlias,
        elevation: 1,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  RecipeImage(recipe: recipe),
                  PositionedDirectional(
                    top: 4,
                    end: 4,
                    child: IconButton.filledTonal(
                      onPressed: () => fav.toggleFavorite(recipe.id),
                      icon: Icon(isFav ? Icons.favorite : Icons.favorite_border,
                          color: isFav ? Colors.red : null),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(recipe.title(en),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 5),
                  Text(meta,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
                  if (recipe.cost(en).isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(recipe.cost(en),
                        style: const TextStyle(
                            fontSize: 11, color: Color(0xFF218838), fontWeight: FontWeight.w600)),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
