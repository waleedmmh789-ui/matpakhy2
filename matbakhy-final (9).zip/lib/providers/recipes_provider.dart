import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import '../models/recipe.dart';

class RecipesProvider extends ChangeNotifier {
  List<Recipe> _recipes = [];
  bool _loading = true;
  String? _error;

  List<Recipe> get recipes => _recipes;
  bool get loading => _loading;
  String? get error => _error;

  Future<void> load() async {
    try {
      final raw = await rootBundle.loadString('assets/data/recipes.json');
      _recipes = (jsonDecode(raw) as List)
          .map((e) => Recipe.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
    } catch (e) {
      _error = e.toString();
    }
    _loading = false;
    notifyListeners();
  }

  Recipe? byId(String? id) {
    if (id == null) return null;
    for (final r in _recipes) {
      if (r.id == id) return r;
    }
    return null;
  }
}
