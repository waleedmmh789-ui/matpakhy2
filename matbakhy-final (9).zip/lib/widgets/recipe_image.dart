import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import '../models/recipe.dart';
import '../services/recipe_image_service.dart';

/// صورة الوصفة بثلاث طبقات أمان:
/// 1) صورة مضمّنة في الوصفة، 2) نسخة محلية/تحميل أول مرة، 3) Asset التصنيف.
/// صورة الـ Asset تظهر فوراً (بدون وميض فراغ) ثم تُستبدل بالصورة الحقيقية عند جاهزيتها.
class RecipeImage extends StatefulWidget {
  final Recipe recipe;
  final BoxFit fit;
  final double? iconSize;

  const RecipeImage({super.key, required this.recipe, this.fit = BoxFit.cover, this.iconSize});

  @override
  State<RecipeImage> createState() => _RecipeImageState();
}

class _RecipeImageState extends State<RecipeImage> {
  File? _file;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant RecipeImage old) {
    super.didUpdateWidget(old);
    if (old.recipe.id != widget.recipe.id) {
      _file = null;
      _load();
    }
  }

  Future<void> _load() async {
    final r = widget.recipe;
    if (r.image.isNotEmpty) return; // للوصفة صورة مضمّنة: لا حاجة للشبكة
    final cached = await RecipeImageService.cachedFile(r);
    if (cached != null) {
      _set(r.id, cached);
      return;
    }
    final fetched = await RecipeImageService.fetch(r);
    if (fetched != null) _set(r.id, fetched);
  }

  void _set(String id, File f) {
    if (!mounted || id != widget.recipe.id) return;
    setState(() => _file = f);
  }

  Widget _fallback() {
    final r = widget.recipe;
    return Image.asset(
      RecipeImageService.fallbackAsset(r),
      fit: widget.fit,
      // آخر خط دفاع: لو حتى الـ Asset فشل
      errorBuilder: (_, __, ___) => ColoredBox(
        color: const Color(0xFFFFE0B2),
        child: Center(child: Icon(Icons.restaurant, size: widget.iconSize ?? 48)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final r = widget.recipe;
    final Widget child;
    if (r.image.isNotEmpty) {
      child = Image.asset(r.image, key: ValueKey('a_${r.id}'), fit: widget.fit, errorBuilder: (_, __, ___) => _fallback());
    } else if (_file != null) {
      child = Image.file(
        _file!,
        key: ValueKey('f_${r.id}'),
        fit: widget.fit,
        cacheWidth: 700, // يوفّر ذاكرة في القوائم الطويلة
        errorBuilder: (_, __, ___) {
          // ملف الكاش تالف: نحذفه ليُعاد تحميله لاحقاً ونعرض الـ Asset الآن.
          scheduleMicrotask(() => RecipeImageService.evict(r));
          return _fallback();
        },
      );
    } else {
      child = KeyedSubtree(key: ValueKey('b_${r.id}'), child: _fallback());
    }
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 250),
      child: SizedBox.expand(key: ValueKey('${r.id}_${_file != null}'), child: child),
    );
  }
}
