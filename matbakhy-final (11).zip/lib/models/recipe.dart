class RecipeStep {
  final int number;
  final String text;
  final int? minutes;
  const RecipeStep({required this.number, required this.text, this.minutes});

  /// يستخرج مدة المؤقت من نص الخطوة (عربي/إنجليزي).
  static int? detectMinutes(String s) {
    final min = RegExp(r'(\d+)(?:\s*-\s*(\d+))?\s*(?:دقيقة|دقائق|minutes|min)').firstMatch(s);
    if (min != null) return int.parse(min.group(2) ?? min.group(1)!);
    final hrs = RegExp(r'(\d+)(?:\s*-\s*(\d+))?\s*(?:ساعات|hours|hour|hrs)').firstMatch(s);
    if (hrs != null) return int.parse(hrs.group(2) ?? hrs.group(1)!) * 60;
    if (s.contains('دقيقتين')) return 2;
    if (s.contains('ساعة')) return 60;
    return null;
  }
}

/// قيم غذائية تقديرية للحصة الواحدة.
class RecipeNutrition {
  final int kcal;
  final double protein, carbs, fat;

  /// نسبة المكونات التي أمكن حساب سعراتها (0–100).
  final int coverage;
  const RecipeNutrition({required this.kcal, required this.protein, required this.carbs, required this.fat, required this.coverage});

  factory RecipeNutrition.fromJson(Map<String, dynamic> j) => RecipeNutrition(
        kcal: (j['kcal'] as num?)?.toInt() ?? 0,
        protein: (j['protein'] as num?)?.toDouble() ?? 0,
        carbs: (j['carbs'] as num?)?.toDouble() ?? 0,
        fat: (j['fat'] as num?)?.toDouble() ?? 0,
        coverage: (j['coverage'] as num?)?.toInt() ?? 0,
      );
}

class Recipe {
  final String id, titleAr, titleEn, cuisineAr, cuisineEn, flag;
  final String timeAr, timeEn, costAr, costEn, descAr, descEn;
  final String image, category, tipsAr, tipsEn;
  /// وصف إنجليزي من 1–2 كلمة (مثل: fish، rice) للبحث عن صورة مناسبة.
  final String imageKeyword;
  final int servings;
  /// سعرات وقيم غذائية تقديرية للحصة الواحدة محسوبة من المكونات (null لو غير متاحة).
  final RecipeNutrition? nutrition;
  final List<Map<String, String>> ingredients;
  final List<String> stepsAr, stepsEn;

  const Recipe({
    required this.id,
    required this.titleAr,
    required this.titleEn,
    required this.cuisineAr,
    required this.cuisineEn,
    required this.flag,
    required this.timeAr,
    required this.timeEn,
    required this.costAr,
    required this.costEn,
    required this.descAr,
    required this.descEn,
    required this.image,
    required this.category,
    required this.tipsAr,
    required this.tipsEn,
    required this.servings,
    this.imageKeyword = '',
    this.nutrition,
    required this.ingredients,
    required this.stepsAr,
    required this.stepsEn,
  });

  static String _s(dynamic v) => (v ?? '').toString();

  factory Recipe.fromJson(Map<String, dynamic> j) => Recipe(
        id: _s(j['id']),
        titleAr: _s(j['titleAr']),
        titleEn: _s(j['titleEn']),
        cuisineAr: _s(j['cuisineAr']),
        cuisineEn: _s(j['cuisineEn']),
        flag: _s(j['flag']),
        timeAr: _s(j['timeAr']),
        timeEn: _s(j['timeEn']),
        costAr: _s(j['costAr']),
        costEn: _s(j['costEn']),
        descAr: _s(j['descAr']),
        descEn: _s(j['descEn']),
        image: _s(j['image']),
        imageKeyword: _s(j['imageKeyword']),
        nutrition: j['nutrition'] is Map ? RecipeNutrition.fromJson(Map<String, dynamic>.from(j['nutrition'] as Map)) : null,
        category: _s(j['category']),
        tipsAr: _s(j['tipsAr']),
        tipsEn: _s(j['tipsEn']),
        servings: (j['servings'] as num?)?.toInt() ?? 4,
        ingredients: ((j['ingredients'] as List?) ?? const [])
            .map((e) => {
                  'ar': _s((e as Map)['ar']),
                  'en': _s(e['en']),
                })
            .toList(),
        stepsAr: List<String>.from((j['stepsAr'] as List?) ?? const []),
        stepsEn: List<String>.from((j['stepsEn'] as List?) ?? const []),
      );

  // أي حقل إنجليزي فاضي يرجع للعربي تلقائياً.
  String _pick(bool en, String ar, String enText) => (en && enText.isNotEmpty) ? enText : ar;

  String title(bool en) => _pick(en, titleAr, titleEn);
  String cuisine(bool en) => _pick(en, cuisineAr, cuisineEn);
  String time(bool en) => _pick(en, timeAr, timeEn);
  String cost(bool en) => _pick(en, costAr, costEn);
  String description(bool en) => _pick(en, descAr, descEn);
  String tips(bool en) => _pick(en, tipsAr, tipsEn);
  String ingredient(int i, bool en) => _pick(en, ingredients[i]['ar'] ?? '', ingredients[i]['en'] ?? '');
  List<String> ingredientList(bool en) =>
      [for (var i = 0; i < ingredients.length; i++) ingredient(i, en)];

  List<RecipeStep> steps(bool en) {
    final raw = (en && stepsEn.isNotEmpty) ? stepsEn : stepsAr;
    return [
      for (var i = 0; i < raw.length; i++)
        RecipeStep(number: i + 1, text: raw[i], minutes: RecipeStep.detectMinutes(raw[i])),
    ];
  }

  String get searchText =>
      '$titleAr $titleEn $cuisineAr $cuisineEn $descAr ${ingredients.map((i) => '${i['ar']} ${i['en']}').join(' ')}'
          .toLowerCase();
}
