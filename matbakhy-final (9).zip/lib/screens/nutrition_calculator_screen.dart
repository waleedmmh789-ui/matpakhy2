import 'package:flutter/material.dart';
import '../widgets/health_disclaimer.dart';
import 'package:provider/provider.dart';
import '../providers/premium_provider.dart';
import '../widgets/calc_unlock_button.dart';
import '../localization/app_localizations.dart';
import '../services/nutrition_calculator.dart';
import '../widgets/banner_ad_widget.dart';
import '../widgets/responsive_body.dart';

class NutritionCalculatorScreen extends StatefulWidget {
  const NutritionCalculatorScreen({super.key});

  @override
  State<NutritionCalculatorScreen> createState() => _NutritionCalculatorScreenState();
}

class _NutritionCalculatorScreenState extends State<NutritionCalculatorScreen> {
  final TextEditingController _controller = TextEditingController();
  final NutritionCalculator _calculator = NutritionCalculator();

  Map<String, dynamic>? _result;
  String? _errorMessage;
  bool _isLoading = true;
  bool _limitReached = false;

  @override
  void initState() {
    super.initState();
    _initCalculator();
  }

  Future<void> _initCalculator() async {
    try {
      await _calculator.loadDatabase();
    } catch (_) {
      _errorMessage = isEnLocale(context)
          ? 'Could not load the nutrition database'
          : 'تعذر تحميل قاعدة البيانات الغذائية';
    }
    if (mounted) setState(() => _isLoading = false);
  }

  void _calculate() {
    setState(() {
      _errorMessage = null;
      _result = null;
      _limitReached = false;
    });

    if (_controller.text.trim().isEmpty) {
      setState(() => _errorMessage = isEnLocale(context)
          ? 'Please write the ingredient and weight in grams (e.g. 250 g beef)'
          : 'من فضلك اكتب المكون والوزن بالجرام (مثلاً: 250 جرام لحمة)');
      return;
    }

    final premium = context.read<PremiumProvider>();
    if (!premium.canUseCalculator) {
      setState(() => _limitReached = true);
      return;
    }

    try {
      final res = _calculator.calculateNutrition(_controller.text, en: isEnLocale(context));
      premium.registerCalcUse();
      setState(() => _result = res);
    } catch (e) {
      setState(() => _errorMessage = e.toString().replaceAll('Exception: ', ''));
    }
  }

  void _quickFill(String text) {
    _controller.text = text;
    _calculate();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final en = isEnLocale(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(t.translate('nutrition_calculator')),
        centerTitle: true,
      ),
      bottomNavigationBar: const SafeArea(top: false, child: BannerAdWidget()),
      body: ResponsiveBody(
        child: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Colors.deepOrange))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const HealthDisclaimerCard(),
                  Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          Text(
                            en ? 'Write the ingredient and weight (in grams)' : 'اكتب المكون والوزن (بالجرام)',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: isDark ? Colors.white : Colors.black87,
                            ),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: _controller,
                            keyboardType: TextInputType.text,
                            decoration: InputDecoration(
                              hintText: en ? 'Example: 250 g beef' : 'مثال: 250 جرام لحمة',
                              filled: true,
                              fillColor: isDark ? Colors.grey[800] : Colors.grey[100],
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide.none,
                              ),
                              prefixIcon: const Icon(Icons.scale, color: Colors.deepOrange),
                            ),
                            onSubmitted: (_) => _calculate(),
                          ),
                          const SizedBox(height: 12),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: _calculate,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.deepOrange,
                                padding: const EdgeInsets.symmetric(vertical: 14),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              ),
                              child: Text(
                                en ? 'Calculate' : 'احسب',
                                style: const TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    en ? 'Quick picks:' : 'اختيارات سريعة:',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: isDark ? Colors.white70 : Colors.grey[700],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _buildQuickChip(en ? '100 g rice' : '100 جرام أرز'),
                      _buildQuickChip(en ? '200 g chicken' : '200 جرام فراخ'),
                      _buildQuickChip(en ? '250 g beef' : '250 جرام لحمة'),
                      _buildQuickChip(en ? '150 g lentils' : '150 جرام عدس'),
                      _buildQuickChip(en ? '50 g oil' : '50 جرام زيت'),
                    ],
                  ),
                  const SizedBox(height: 24),
                  if (_errorMessage != null)
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.red.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.red),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.error_outline, color: Colors.red),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              _errorMessage!,
                              style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                    ),
                  Builder(builder: (ctx) {
                    final pr = ctx.watch<PremiumProvider>();
                    if (!pr.loaded || pr.isPremium) return const SizedBox.shrink();
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Text(
                        en
                            ? 'Calculator uses left: ${pr.calcRemainingUses}'
                            : 'الاستخدامات المتبقية للحاسبة: ${pr.calcRemainingUses}',
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.deepOrange),
                      ),
                    );
                  }),
                  if (_limitReached && !context.watch<PremiumProvider>().canUseCalculator)
                    Card(
                      color: Colors.orange.withOpacity(0.1),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            Text(
                              en
                                  ? 'You have no calculator uses left.'
                                  : 'انتهت استخدامات الحاسبة.',
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 10),
                            const CalcUnlockButton(),
                          ],
                        ),
                      ),
                    ),
                  if (_result != null) _buildResultCard(_result!),
                ],
              ),
            ),
      ),
    );
  }

  Widget _buildQuickChip(String label) {
    return ActionChip(
      label: Text(label, style: const TextStyle(fontSize: 12)),
      onPressed: () => _quickFill(label),
      backgroundColor: Theme.of(context).cardColor,
      side: const BorderSide(color: Colors.deepOrange, width: 1),
      labelStyle: const TextStyle(color: Colors.deepOrange),
    );
  }

  Widget _buildResultCard(Map<String, dynamic> result) {
    final en = isEnLocale(context);
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      color: Colors.deepOrange.withOpacity(0.05),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Text(
              en
                  ? 'Result (${result['ingredient_name_en']})'
                  : 'النتيجة (${result['ingredient_name']})',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.deepOrange),
            ),
            const SizedBox(height: 4),
            Text(
              en
                  ? 'Weight: ${(result['weight_grams'] as double).toStringAsFixed(0)} g'
                  : 'الوزن: ${(result['weight_grams'] as double).toStringAsFixed(0)} جرام',
              style: const TextStyle(fontSize: 14, color: Colors.grey, fontWeight: FontWeight.bold),
            ),
            const Divider(),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildNutrient(en ? 'Calories' : 'سعرات', (result['calories'] as num).toStringAsFixed(0), 'kcal', Colors.red),
                _buildNutrient(en ? 'Protein' : 'بروتين', (result['protein'] as num).toStringAsFixed(1), 'g', Colors.blue),
                _buildNutrient(en ? 'Carbs' : 'كارب', (result['carbs'] as num).toStringAsFixed(1), 'g', Colors.orange),
                _buildNutrient(en ? 'Fat' : 'دهون', (result['fat'] as num).toStringAsFixed(1), 'g', Colors.green),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              en
                  ? '* Numbers are estimates based on average nutrition values per 100 g (weight is raw unless "cooked", "boiled" or "grilled" is mentioned).'
                  : '* الأرقام تقديرية بناءً على متوسط القيم الغذائية لكل 100 جرام (الوزن نيئ ما لم يُذكر "مطبوخ" أو "مسلوق" أو "مشوية").',
              style: const TextStyle(fontSize: 10, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNutrient(String label, String value, String unit, Color color) {
    return Column(
      children: [
        Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: color)),
        Text(unit, style: const TextStyle(fontSize: 12, color: Colors.grey)),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
      ],
    );
  }
}
