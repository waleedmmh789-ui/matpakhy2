import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FavoritesProvider extends ChangeNotifier {
  Set<String> _ids = {};
  bool isFavorite(String id) => _ids.contains(id);

  Future<void> loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    // 'favorites' هو المفتاح الجديد، و'favorite_ids' مفتاح نسخة سفرتنا القديمة
    _ids = {...(prefs.getStringList('favorites') ?? []), ...(prefs.getStringList('favorite_ids') ?? [])};
    notifyListeners();
  }

  Future<void> toggleFavorite(String id) async {
    if (!_ids.remove(id)) _ids.add(id);
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('favorites', _ids.toList());
  }
}
