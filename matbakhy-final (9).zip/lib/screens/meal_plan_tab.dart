import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../localization/app_localizations.dart';
import '../models/recipe.dart';
import '../providers/meal_plan_provider.dart';
import '../providers/recipes_provider.dart';
import 'home_screen.dart' show isEnglish;

class MealPlanTab extends StatelessWidget {
  const MealPlanTab({super.key});

  static const _daysAr = ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
  static const _daysEn = ['Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final en = isEnglish(context);
    final plan = context.watch<MealPlanProvider>();
    final data = context.watch<RecipesProvider>();
    final days = en ? _daysEn : _daysAr;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(t.translate('meal_plan'),
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(t.translate('meal_hint')),
        const SizedBox(height: 12),
        for (var i = 0; i < 7; i++)
          Card(
            child: ListTile(
              leading: CircleAvatar(child: Text('${i + 1}')),
              title: Text(days[i]),
              subtitle: Text(data.byId(plan.mealFor(i))?.title(en) ?? t.translate('no_meal')),
              trailing: plan.mealFor(i) == null
                  ? const Icon(Icons.edit)
                  : IconButton(
                      tooltip: t.translate('clear_meal'),
                      icon: const Icon(Icons.close),
                      onPressed: () => plan.setMeal(i, null),
                    ),
              onTap: () async {
                final choice = await showModalBottomSheet<Recipe>(
                  context: context,
                  isScrollControlled: true,
                  builder: (_) => _Picker(recipes: data.recipes),
                );
                if (choice != null) plan.setMeal(i, choice.id);
              },
            ),
          ),
      ],
    );
  }
}

class _Picker extends StatefulWidget {
  final List<Recipe> recipes;
  const _Picker({required this.recipes});

  @override
  State<_Picker> createState() => _PickerState();
}

class _PickerState extends State<_Picker> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final en = isEnglish(context);
    final q = _q.trim().toLowerCase();
    final list = q.isEmpty
        ? widget.recipes
        : widget.recipes.where((r) => r.searchText.contains(q)).toList();

    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: SizedBox(
          height: MediaQuery.of(context).size.height * .7,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: TextField(
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search),
                    hintText: t.translate('search_hint'),
                    border: const OutlineInputBorder(),
                  ),
                  onChanged: (v) => setState(() => _q = v),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (context, i) => ListTile(
                    title: Text(list[i].title(en)),
                    subtitle: Text(list[i].cuisine(en)),
                    onTap: () => Navigator.pop(context, list[i]),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
