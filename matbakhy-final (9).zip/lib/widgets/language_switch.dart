import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/settings_provider.dart';

/// زر تبديل اللغة (ع | EN) وفوقه كلمة "اللغة" — يوضع بجوار اسم التطبيق.
class LanguageSwitch extends StatelessWidget {
  const LanguageSwitch({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    final en = settings.isEnglish;
    Widget seg(String text, bool selected) => AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
          decoration: BoxDecoration(
            color: selected ? Colors.white : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(
            text,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              color: selected ? Colors.deepOrange : Colors.white,
            ),
          ),
        );
    return Padding(
      padding: const EdgeInsetsDirectional.only(start: 10),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(en ? 'Language' : 'اللغة',
                style: const TextStyle(fontSize: 10, color: Colors.white70, height: 1.1)),
            const SizedBox(height: 2),
            GestureDetector(
              onTap: () => context.read<SettingsProvider>().setLanguage(en ? 'ar' : 'en'),
              child: Container(
                padding: const EdgeInsets.all(2),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.white70),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Directionality(
                  textDirection: TextDirection.ltr,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [seg('ع', !en), seg('EN', en)],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
